import time
import RPi.GPIO as GPIO
import spidev

# --- Pin mapping (BCM numbering) ---
CS_GYR = 17   # header pin 11
CS_ACC = 27   # header pin 13

# BMI088 registers (minimal set)
GYR_CHIP_ID_REG  = 0x00  # expect 0x0F
ACC_CHIP_ID_REG  = 0x00  # expect 0x1E

# SPI read: set MSB=1 for read, MSB=0 for write
def _rd_addr(addr): return addr | 0x80
def _wr_addr(addr): return addr & 0x7F

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(CS_GYR, GPIO.OUT, initial=GPIO.HIGH)
GPIO.setup(CS_ACC, GPIO.OUT, initial=GPIO.HIGH)

# Setup SPI0
spi = spidev.SpiDev()
spi.open(0, 0)             # bus 0, device 0 (we won't use CE0 line)
spi.max_speed_hz = 5_000_000
spi.mode = 0               # BMI088 uses SPI mode 0
spi.no_cs = True           # we'll toggle CS manually

def spi_xfer(cs_pin, tx):
    GPIO.output(cs_pin, GPIO.LOW)
    rx = spi.xfer2(tx)
    GPIO.output(cs_pin, GPIO.HIGH)
    return rx

def read_reg(cs_pin, reg):
    # Send [addr|0x80, dummy] and read back 1 data byte
    _, data = spi_xfer(cs_pin, [_rd_addr(reg), 0x00])
    return data

def read_regs(cs_pin, start_reg, length):
    # Burst read: [addr|0x80] + length dummy bytes
    tx = [_rd_addr(start_reg)] + [0x00]*length
    rx = spi_xfer(cs_pin, tx)
    return rx[1:]  # first byte is status echo

def write_reg(cs_pin, reg, val):
    spi_xfer(cs_pin, [_wr_addr(reg), val])
    # per datasheet, small delay can help after some writes
    time.sleep(0.00002)

try:
    time.sleep(0.05)

    # --- Read Chip IDs ---
    gyr_id = read_reg(CS_GYR, GYR_CHIP_ID_REG)
    acc_id = read_reg(CS_ACC, ACC_CHIP_ID_REG)

    print(f"Gyro CHIP_ID:  0x{gyr_id:02X} (expect 0x0F)")
    print(f"Accel CHIP_ID: 0x{acc_id:02X} (expect 0x1E)")

    # Quick sanity check
    ok = (gyr_id == 0x0F) and (acc_id == 0x1E)
    print("BMI088 detected!" if ok else "Unexpected IDs—check wiring, power, or SPI mode/speed.")

finally:
    spi.close()
    GPIO.cleanup([CS_GYR, CS_ACC])
