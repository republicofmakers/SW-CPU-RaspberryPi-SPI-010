#!/usr/bin/env python3
# bmi088_spi_fix2.py — Raspberry Pi 4 + BMI088 (SPI0) with manual CS and accel dummy byte
import time
import spidev
import RPi.GPIO as GPIO

# Header pins → BCM GPIOs
CS_GYR = 17   # pin 11
CS_ACC = 27   # pin 13

# Common
REG_CHIP_ID   = 0x00
GYR_ID_EXPECT = 0x0F
ACC_ID_EXPECT = 0x1E

# --- Accelerometer registers (CORRECT ADDRESSES) ---
ACC_CONF       = 0x40
ACC_RANGE      = 0x41
ACC_DATA_START = 0x12
ACC_PWR_CONF   = 0x7C    # correct
ACC_PWR_CTRL   = 0x7D    # correct
ACC_SOFTRESET  = 0x7E    # write 0xB6

# --- Gyroscope registers ---
GYR_RANGE      = 0x0F
GYR_BW         = 0x10
GYR_DATA_START = 0x02
GYR_SOFTRESET  = 0x14

# Scaling
ACC_G_PER_LSB   = 3.0 / 2048.0
GYR_DPS_PER_LSB = 2000.0 / 32768.0

spi = spidev.SpiDev()

def setup_gpio():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(CS_GYR, GPIO.OUT, initial=GPIO.HIGH)
    GPIO.setup(CS_ACC, GPIO.OUT, initial=GPIO.HIGH)

def setup_spi(hz=500_000):
    spi.open(0, 0)
    spi.max_speed_hz = hz
    spi.mode = 0
    try: spi.no_cs = True
    except AttributeError: pass

def xfer(cs, tx):
    GPIO.output(cs, GPIO.LOW)
    time.sleep(0.000002)
    rx = spi.xfer2(tx)
    GPIO.output(cs, GPIO.HIGH)
    return rx

# ---- Gyro helpers (no dummy) ----
def gyr_wr(reg, val): xfer(CS_GYR, [reg & 0x7F, val]); time.sleep(0.00002)
def gyr_rd(reg):      return xfer(CS_GYR, [reg | 0x80, 0x00])[1]
def gyr_rds(reg, n):  return xfer(CS_GYR, [reg | 0x80] + [0x00]*n)[1:]

# ---- Accel helpers (READ needs dummy byte) ----
def acc_wr(reg, val): xfer(CS_ACC, [reg & 0x7F, val]); time.sleep(0.00002)
def acc_rd(reg):      return xfer(CS_ACC, [reg | 0x80, 0x00, 0x00])[2]
def acc_rds(reg, n):  return xfer(CS_ACC, [reg | 0x80] + [0x00]*(n+1))[2:]

# ---- Init sequences ----
def accel_init():
    # soft reset
    acc_wr(ACC_SOFTRESET, 0xB6)
    time.sleep(0.05)

    # per datasheet: write PWR_CTRL=0x04 (Normal), wait >=450 us
    # but first ensure PWR_CONF has default (no power save)
    acc_wr(ACC_PWR_CONF, 0x00)
    time.sleep(0.001)
    acc_wr(ACC_PWR_CTRL, 0x04)
    time.sleep(0.001)  # >= 450 us

    # configure ODR/BW and range
    acc_wr(ACC_CONF,  0xA8)  # ~1600 Hz, OSR4
    acc_wr(ACC_RANGE, 0x03)  # ±3 g

def gyro_init():
    gyr_wr(GYR_SOFTRESET, 0xB6)
    time.sleep(0.05)
    gyr_wr(GYR_RANGE, 0x00)  # ±2000 dps
    gyr_wr(GYR_BW,    0x07)  # 2000 Hz / ~532 Hz BW

# ---- Data helpers ----
def s16(msb, lsb):
    v = (msb << 8) | lsb
    return v - 0x10000 if v & 0x8000 else v

def read_accel_raw():
    b = acc_rds(ACC_DATA_START, 6)
    x = s16(b[1], b[0]) >> 4
    y = s16(b[3], b[2]) >> 4
    z = s16(b[5], b[4]) >> 4
    return x, y, z

def read_gyro_raw():
    b = gyr_rds(GYR_DATA_START, 6)
    x = s16(b[1], b[0])
    y = s16(b[3], b[2])
    z = s16(b[5], b[4])
    return x, y, z

def main():
    setup_gpio()
    setup_spi(500_000)
    try:
        # Switch accel into SPI mode with a dummy read early
        _ = acc_rd(REG_CHIP_ID)

        # Probe IDs
        print(f"Pre-init: GYR_ID=0x{gyr_rd(REG_CHIP_ID):02X}, ACC_ID=0x{acc_rd(REG_CHIP_ID):02X}")

        accel_init()
        gyro_init()

        gid = gyr_rd(REG_CHIP_ID)
        aid = acc_rd(REG_CHIP_ID)
        pwc = acc_rd(ACC_PWR_CONF)
        pwr = acc_rd(ACC_PWR_CTRL)
        print(f"Post-init: GYR_ID=0x{gid:02X}, ACC_ID=0x{aid:02X}")
        print(f"ACC_PWR_CONF=0x{pwc:02X}, ACC_PWR_CTRL=0x{pwr:02X} (expect 0x00, 0x04)")

        spi.max_speed_hz = 1_000_000

        while True:
            ax, ay, az = read_accel_raw()
            gx, gy, gz = read_gyro_raw()
            ax_ms2 = ax * ACC_G_PER_LSB * 9.80665
            ay_ms2 = ay * ACC_G_PER_LSB * 9.80665
            az_ms2 = az * ACC_G_PER_LSB * 9.80665
            gx_dps = gx * GYR_DPS_PER_LSB
            gy_dps = gy * GYR_DPS_PER_LSB
            gz_dps = gz * GYR_DPS_PER_LSB
            print(f"{ax_ms2:.3f},{ay_ms2:.3f},{az_ms2:.3f},{gx_dps:.3f},{gy_dps:.3f},{gz_dps:.3f}")
            time.sleep(0.5)
    finally:
        try: spi.close()
        except: pass
        GPIO.cleanup([CS_GYR, CS_ACC])

if __name__ == "__main__":
    main()
