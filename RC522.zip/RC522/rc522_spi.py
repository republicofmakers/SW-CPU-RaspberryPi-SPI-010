import spidev
import time
import RPi.GPIO as GPIO

# Manual CS and RST on Raspberry Pi 4B
CS_PIN  = 17   # SDA → Pin 11
RST_PIN = 27   # RST → Pin 13

class MFRC522:
    def __init__(self):
        # Setup GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(CS_PIN, GPIO.OUT, initial=GPIO.HIGH)
        GPIO.setup(RST_PIN, GPIO.OUT, initial=GPIO.HIGH)

        # Setup SPI
        self.spi = spidev.SpiDev()
        self.spi.open(0, 0)             # SPI0
        self.spi.max_speed_hz = 250000
        self.spi.mode = 0
        self.spi.no_cs = True           # manual chip select

        self.reset()
        # init registers
        self.write(0x2A, 0x8D)
        self.write(0x2B, 0x3E)
        self.write(0x2D, 30)
        self.write(0x2C, 0)
        self.write(0x15, 0x40)
        self.write(0x11, 0x3D)
        self.antenna_on()

    def reset(self):
        GPIO.output(RST_PIN, GPIO.LOW); time.sleep(0.1)
        GPIO.output(RST_PIN, GPIO.HIGH); time.sleep(0.1)
        self.write(0x01, 0x0F)  # Soft reset
        time.sleep(0.05)

    def write(self, reg, val):
        GPIO.output(CS_PIN, GPIO.LOW)
        self.spi.xfer2([(reg << 1) & 0x7E, val])
        GPIO.output(CS_PIN, GPIO.HIGH)

    def read(self, reg):
        GPIO.output(CS_PIN, GPIO.LOW)
        resp = self.spi.xfer2([((reg << 1) & 0x7E) | 0x80, 0])
        GPIO.output(CS_PIN, GPIO.HIGH)
        return resp[1]

    def set_bitmask(self, reg, mask):
        self.write(reg, self.read(reg) | mask)

    def clear_bitmask(self, reg, mask):
        self.write(reg, self.read(reg) & (~mask & 0xFF))

    def antenna_on(self):
        if not (self.read(0x14) & 0x03):
            self.set_bitmask(0x14, 0x03)

    def request(self, mode):
        self.write(0x0D, 0x07)     # TxLastBits = 7
        self.write(0x01, 0x00)     # Idle
        self.write(0x0A, 0x80)     # Flush FIFO
        self.write(0x09, mode)     # Send REQA
        self.write(0x01, 0x0C)     # Transceive
        self.set_bitmask(0x0D, 0x80) # StartSend

        for _ in range(2000):
            irq = self.read(0x04)
            if irq & 0x30:
                break

        if self.read(0x06) & 0x1B:
            return False
        return True

    def anticoll_full(self):
        """Return full UID (4/7/10 bytes)."""
        uid = []
        for cascade_cmd in (0x93, 0x95, 0x97):  # Cascade Levels 1–3
            self.write(0x0D, 0x00)     # bit framing
            self.write(0x01, 0x00)     # Idle
            self.write(0x0A, 0x80)     # Flush FIFO
            self.write(0x09, cascade_cmd)
            self.write(0x09, 0x20)     # NVB = 0x20 (anticoll)
            self.write(0x01, 0x0C)     # Transceive
            self.set_bitmask(0x0D, 0x80)

            for _ in range(5000):
                irq = self.read(0x04)
                if irq & 0x30:
                    break
                time.sleep(0.001)

            if self.read(0x06) & 0x1B:
                return None

            length = self.read(0x0A)
            if length == 0:
                return None
            data = [self.read(0x09) for _ in range(length)]

            if not data or len(data) < 5:
                return None

            # If first byte == 0x88, it’s a cascade tag → UID continues
            if data[0] == 0x88:
                uid.extend(data[1:4])
            else:
                uid.extend(data[0:4])
                break  # UID complete

        return uid

# ==== Main ====
if __name__ == "__main__":
    rc522 = MFRC522()
    print("Bring a card close to the reader...")

    try:
        while True:
            if rc522.request(0x26):   # REQA
                uid = rc522.anticoll_full()
                if uid:
                    uid_str = ":".join(f"{x:02X}" for x in uid)
                    print(f"Card UID: {uid_str}")
                    time.sleep(1)
            time.sleep(0.2)
    finally:
        GPIO.cleanup()
